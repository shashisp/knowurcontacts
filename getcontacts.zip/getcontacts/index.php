<html>
<head>
<head>
<title>GetmyContacts</title>
    <link rel="stylesheet" href="http://bootswatch.com/flatly/bootstrap.css" media="screen">
    <link rel="stylesheet" href="http://bootswatch.com/bower_components/font-awesome/css/font-awesome.min.css" media="screen">
    <link rel="stylesheet" href="http://bootswatch.com/assets/css/bootswatch.min.css">


</head>
<body>

        <div class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <a href="./" class="navbar-brand">GetyourContacts</a>
        
        </div>
      </div>
    </div>


	
              <div class="splash">
      <div class="container">

        <div class="row">
          <div class="col-lg-12">
            <h1>GetyourContacts</h1>
            
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="section-tout">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <h3><i class="fa fa-cloud"></i> GetyourContacts</h3>
            <p>Just another Simple app, Fetches your Contacts Details</p>
          </div>
          <div class="col-lg-4 col-sm-6">
              <h3><i class="fa fa-cogs"></i>Technologies Used</h3>
            <p>It uses Googles Oauth2 API and PHP</p>
          </div>
          <div class="col-lg-4 col-sm-6">
            <h3><i class="fa fa-github"></i> Check out the source code on github</h3>
            <p><a target="_blank" href="https://github.com/shashisp/geturcontacts">Source code</a></p>  
          </div>
          
        </div>

      </div>
    </div>

            
          
               <center>
                <p><a href="https://accounts.google.com/o/oauth2/auth?client_id=133186028197-lpsptdcfl3jhv9dpgft7jadi5aure6du.apps.googleusercontent.com&redirect_uri=http://localhost/oauth/oauth.php&scope=https://www.google.com/m8/feeds/&response_type=code" class="btn btn-info btn-lg">Try Demo >></a></p>
               </center>      

</body>
</html>